# BloodCounts — Blood Donor Finder (Hackathon MVP)

**Tagline:** Every Drop Counts. Every Donor Matters.

A responsive vanilla HTML/CSS/JavaScript application that uses Firebase Authentication, Cloud Firestore, Leaflet and OpenStreetMap. This is a college hackathon MVP starter, not a production medical service.

## Architecture

- **Static frontend:** HTML5, CSS3 and vanilla ES modules. No React, Vue, Angular, Bootstrap or Tailwind.
- **Authentication:** Firebase Email/Password and optional Firebase Phone Authentication with reCAPTCHA.
- **Database:** Cloud Firestore collections: `users`, `donors`, `donorSearch`, `bloodRequests`, `notifications`, `bloodRequests/{id}/responses`, and `facilities`.
- **Maps:** Leaflet with OpenStreetMap tiles. Default map center is a neutral Dehradun-area starting view, not a claim about the user's location. Real markers only load from configured Firestore data.
- **Trusted backend:** Firebase Cloud Functions syncs a privacy-reduced donor discovery record, creates compatible donor notifications, validates donor responses, reveals contact details only to the authorized request owner after acceptance, and schedules request expiry/radius escalation.

## Pages

- `index.html`: landing page and quick search.
- `register-account.html`: email/password account creation.
- `login.html`: email/password and real Firebase phone OTP UI.
- `register.html`: donor profile registration and preliminary screening.
- `find-donors.html`: compatibility filtering, distance sorting and map.
- `request-blood.html`: authenticated blood request creation.
- `dashboard.html`: donor profile, own requests and incoming notifications.
- `facilities.html`: Firestore-backed facility directory.

## 1. Open the project in VS Code

1. Install [Visual Studio Code](https://code.visualstudio.com/) if it is not installed.
2. Extract the project folder and open **File → Open Folder → `bloodcounts`**.
3. Install the VS Code **Live Server** extension, or use another static development server. Do not open the HTML files directly with `file://` because ES modules and Firebase require an HTTP origin.
4. Keep the folder structure intact.

## 2. Create and configure Firebase

1. Open [Firebase Console](https://console.firebase.google.com/) and create a project.
2. In Project settings, register a **Web app** and copy its web configuration.
3. Open `js/firebase-config.js` and replace every `YOUR_...` placeholder with the values from the console. Never paste a service-account JSON or private server key into browser JavaScript.
4. In **Build → Authentication → Sign-in method**, enable **Email/Password**. To use phone login, enable **Phone**, configure test phone numbers if desired, and follow Firebase's current SMS/billing requirements.
5. In **Authentication → Settings**, add your local development hostname (for example `localhost`) and deployed Hosting domain to authorized domains. Phone auth uses Firebase's reCAPTCHA flow; test on an allowed domain.
6. In **Build → Firestore Database**, create a database. Start in production mode, then deploy the included rules and indexes.

## 3. Install Firebase CLI and deploy rules

Install a supported Node.js LTS version only for Firebase tooling and Cloud Functions deployment; the frontend itself remains vanilla browser JavaScript. Then run in a terminal:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore:rules,firestore:indexes
```

Choose the Firebase project you created. `firebase use --add` creates or updates the local project alias file. If prompted for a project ID, use your real project ID.

## 4. Deploy Cloud Functions

From the `bloodcounts` root:

```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

The scheduled function `expireAndEscalateRequests` needs Cloud Scheduler / scheduled-functions support in your Firebase/Google Cloud project. Billing requirements can vary by project and current Firebase/Google Cloud terms; check the console before enabling it. Do not assume scheduling is active until deployment succeeds and function logs show executions.

The backend uses the Admin SDK, which bypasses Firestore client rules. Secure the Google Cloud project, restrict administrative IAM roles, and never expose Admin credentials in the frontend.

## 5. Run locally

1. Start Live Server from `index.html` or run another local static server.
2. Replace Firebase placeholders before testing any Firebase-backed page.
3. Open the page at its HTTP URL (for example `http://127.0.0.1:5500`). Ensure that URL/domain is allowed by Firebase Authentication.
4. Open browser developer tools if a Firebase error appears. Never work around a permission error by opening every collection publicly.

## 6. Configure verified facility records

Create Firestore documents in `facilities` using fields like:

```json
{
  "name": "Facility name verified by an administrator",
  "type": "blood_bank",
  "address": "Verified street address",
  "city": "Verified city",
  "locality": "Verified locality",
  "phone": "Publicly listed phone number, if verified",
  "latitude": 30.3,
  "longitude": 78.0,
  "active": true
}
```

These values are examples of the schema only, **not a real facility listing**. Do not publish invented addresses, phone numbers, blood stock or availability. Only administrators should create or modify facility documents.

## 7. Firestore collection design and privacy

| Collection | Contents | Access |
|---|---|---|
| `users/{uid}` | Account display name and email | Owner reads; owner creates and can update display name |
| `donors/{uid}` | Private donor profile, contact details, eligibility inputs and consent | Owner reads/writes own profile; trusted backend reads privately |
| `donorSearch/{uid}` | Sanitized public donor card, blood group, city/locality and rounded approximate coordinates | Public read; backend-only writes |
| `bloodRequests/{requestId}` | Request details, owner UID, private contact information, status and timestamps | Owner reads/creates; owner may cancel; backend controls expiry/escalation and sensitive status changes |
| `bloodRequests/{requestId}/responses/{donorUid}` | One response per donor/request | Target donor and request owner can read; backend writes |
| `notifications/{notificationId}` | Request summary and target donor UID | Target donor reads; backend creates/updates |
| `facilities/{facilityId}` | Administrator-verified facility directory records | Active facilities readable; admin-only writes |

The contact phone for a requester is in the owner-readable request document. Donor phone/email are **not** copied to `donorSearch` or notifications. `getAuthorizedDonorContact` only returns a donor's contact to the request owner after the donor has accepted. Keep any contact display UI behind this callable function; do not query private donor records from public pages.

## 8. Core workflows and limitations

- **Compatibility:** reusable `js/compatibility.js` follows the recipient-to-donor mapping in the project specification. It is only a search filter; clinical staff must verify blood type and crossmatch.
- **Eligibility:** age 18–65, default 50 kg minimum, availability, self-reported health, and configurable 3-month/4-month intervals are preliminary checks. They do not replace current Indian blood-donation guidelines or clinician assessment. The UI does not collect a detailed medical history.
- **Discovery:** the browser queries the sanitized `donorSearch` collection. The backend rounds coordinates to two decimal places before publishing; this is approximate and can still reveal a broad area. For stronger privacy, use geohash/radius buckets and only disclose location with donor consent.
- **Request matching:** Cloud Function filters eligible, available and compatible profiles by approximate distance and creates in-app notification documents. SMS, email and push notifications are not enabled by this source alone.
- **Escalation:** scheduled backend processing expands radius from 5 to 10, 20 and 50 km after five-minute intervals, avoids repeating notifications to the same donor, and expires requests after the required-by deadline. This depends on deployed and functioning scheduled Cloud Functions.
- **Phone OTP:** the page calls Firebase's real `signInWithPhoneNumber` flow; it is not a simulated OTP. It requires correct project setup, reCAPTCHA and Firebase's current phone-auth requirements.
- **Language toggle:** English/Hindi translation data and a working toggle are included for the navigation and currently marked interface strings. Not every form validation sentence is fully translated yet.
- **Map tiles:** OpenStreetMap tile service is used with attribution. Follow the tile usage policy; do not treat the map as a verified healthcare directory.
- **Abuse prevention:** before public launch, add App Check, rate limiting, request quotas, abuse reporting, moderation, audit logs, retention/deletion policy, stronger server-side schema validation and an administrator workflow.

## 9. Security notes before a public demo

The provided Firestore rules restrict private donor data and request ownership. A production deployment should additionally:

- Validate every request field and allowed status transition in trusted backend code, not only in the browser/rules.
- Use Firebase App Check and consider rate limits/quotas to limit spam.
- Ensure Admin custom claims are set only by a trusted administrator.
- Review the public `donorSearch` location precision and donor consent wording with your institution.
- Add a trusted admin process for marking requests fulfilled and reviewing facilities.
- Test all rules with the Firebase Emulator Suite and adversarial account scenarios.
- Avoid presenting this application as a guaranteed blood supply or medical service.

## 10. Testing checklist

- [ ] Create an email/password account; duplicate email and invalid password produce useful errors.
- [ ] Login and logout; refresh retains the Firebase session.
- [ ] Phone OTP sends a real Firebase SMS in an eligible project; invalid OTP and denied reCAPTCHA show errors.
- [ ] Donor form rejects malformed phone/email, age outside 18–65, weight below 50 kg, future donation date and missing consent.
- [ ] Verify compatibility for all eight recipient blood groups.
- [ ] Verify eligibility interval checks for men/women and that failed checks are explained.
- [ ] Verify donors who are unavailable/inactive or preliminary-ineligible are not returned.
- [ ] Verify donor results do not expose phone/email or exact address.
- [ ] Test location permission allowed, denied, unsupported and manual city fallback.
- [ ] Create a future-dated blood request while authenticated; unauthenticated creation is rejected.
- [ ] Verify a request generates notifications for compatible eligible donors within the initial radius.
- [ ] Verify donor can accept/decline only their own notification and cannot respond twice.
- [ ] Verify requester cannot retrieve donor contact before acceptance or for another request.
- [ ] Verify request owner can cancel their own request but cannot edit another person's request.
- [ ] Verify scheduled escalation expands radius without duplicate donor notifications.
- [ ] Verify expired requests stop escalation and are no longer open.
- [ ] Verify facility directory only displays administrator-added records.
- [ ] Verify English/Hindi toggle and mobile layout at narrow viewport sizes.
- [ ] Use Firestore Emulator/rules unit tests to attempt unauthorized reads/writes.

## 11. Suggested hackathon demo (3–4 minutes)

1. Show the landing page and responsive design.
2. Create a demo user account and log in.
3. Register a donor with sample data explicitly marked as demo data.
4. Create a blood request for a compatible blood group and a location you are authorized to use.
5. Log in as the donor account and show the in-app notification; accept it.
6. Show that contact details are not on the public donor card and are only returned through the authorized server function after acceptance.
7. Demonstrate the map, distance sorting, Hindi toggle and the preliminary eligibility warning.
8. Finish by showing the Firestore rules and explain that real SMS delivery, clinical eligibility and verified facility records require configuration and human oversight.

## Medical and operational disclaimer

BloodCounts is a hackathon demonstration, not a medical device, blood bank, emergency dispatch service or guarantee of donor availability. For emergencies, contact the treating hospital/blood bank or local emergency services directly. All donation eligibility and transfusion decisions must be made by qualified medical personnel.
