const admin = require('firebase-admin');
const { onDocumentCreated, onDocumentWritten } = require('firebase-functions/v2/firestore');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
admin.initializeApp();
const db = admin.firestore();
const FieldValue = admin.firestore.FieldValue;
const BLOOD_GROUPS = ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'];
const COMPAT = { 'O-':['O-'], 'O+':['O-','O+'], 'A-':['O-','A-'], 'A+':['O-','O+','A-','A+'], 'B-':['O-','B-'], 'B+':['O-','O+','B-','B+'], 'AB-':['O-','A-','B-','AB-'], 'AB+':BLOOD_GROUPS };
const RADIUS_STAGES = [5, 10, 20, 50];
const ESCALATION_MINUTES = 5;
function compatible(donor, recipient) { return Boolean(COMPAT[recipient]?.includes(donor)); }
function distanceKm(aLat,aLon,bLat,bLon) { const rad=x=>x*Math.PI/180; const dLat=rad(bLat-aLat),dLon=rad(bLon-aLon);const a=Math.sin(dLat/2)**2+Math.cos(rad(aLat))*Math.cos(rad(bLat))*Math.sin(dLon/2)**2;return 6371*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a)); }
function eligibility(d, now = new Date()) {
  const reasons=[];const age=Number(d.age),weight=Number(d.weightKg);
  if(!Number.isFinite(age)||age<18||age>65)reasons.push('Age outside configured preliminary range');
  if(!Number.isFinite(weight)||weight<50)reasons.push('Weight below configured preliminary threshold');
  if(d.available!==true)reasons.push('Unavailable');if(d.feelingHealthy!==true)reasons.push('Not marked as feeling healthy');
  if(d.lastDonationDate){const last=new Date(`${d.lastDonationDate}T00:00:00`);if(Number.isNaN(last.getTime())||last>now)reasons.push('Invalid last donation date');else{const elapsed=(now.getFullYear()-last.getFullYear())*12+now.getMonth()-last.getMonth()-(now.getDate()<last.getDate()?1:0);const interval=d.gender==='male'?3:4;if(elapsed<interval)reasons.push('Donation interval not reached');}}
  return { eligible:reasons.length===0,reasons };
}
function isValidCoord(lat,lon){return Number.isFinite(Number(lat))&&Number(lat)>=-90&&Number(lat)<=90&&Number.isFinite(Number(lon))&&Number(lon)>=-180&&Number(lon)<=180;}
function safeDiscovery(d, uid) {
  const assess=eligibility(d);
  return { uid, fullName: String(d.fullName||'Registered donor').slice(0,100), bloodGroup:d.bloodGroup, city:String(d.city||'').slice(0,100), locality:String(d.locality||'').slice(0,100), state:String(d.state||'').slice(0,100), latitude:isValidCoord(d.latitude,d.longitude)?Math.round(Number(d.latitude)*100)/100:null, longitude:isValidCoord(d.latitude,d.longitude)?Math.round(Number(d.longitude)*100)/100:null, available:d.available===true, active:d.active===true, preliminaryEligible:assess.eligible, updatedAt:FieldValue.serverTimestamp() };
}
// Mirror only privacy-safe fields into donorSearch. Private donor records remain owner-readable only.
exports.syncDonorSearch = onDocumentWritten('donors/{uid}', async event => {
  const uid=event.params.uid, after=event.data.after;
  const target=db.collection('donorSearch').doc(uid);
  if(!after.exists){await target.delete().catch(()=>{});return;}
  const d=after.data();
  if(!d.active || !d.consent || !BLOOD_GROUPS.includes(d.bloodGroup)){await target.delete().catch(()=>{});return;}
  await target.set(safeDiscovery(d,uid));
});
async function createNotificationsForRadius(requestId, req, radiusKm, stage) {
  if(!isValidCoord(req.latitude,req.longitude)) return 0;
  const snapshot=await db.collection('donorSearch').where('active','==',true).where('available','==',true).get();
  const already=new Set(req.notifiedDonorUids||[]);const batch=db.batch();let count=0;const now=admin.firestore.Timestamp.now();
  for(const snap of snapshot.docs){const d=snap.data();if(already.has(snap.id)||!d.preliminaryEligible||!compatible(d.bloodGroup,req.bloodGroup)||!isValidCoord(d.latitude,d.longitude))continue;
    const km=distanceKm(Number(req.latitude),Number(req.longitude),Number(d.latitude),Number(d.longitude));if(km>radiusKm)continue;
    const ref=db.collection('notifications').doc();batch.set(ref,{donorUid:snap.id,requestId,bloodGroup:req.bloodGroup,hospitalName:req.hospitalName,city:req.city,latitude:Math.round(Number(req.latitude)*100)/100,longitude:Math.round(Number(req.longitude)*100)/100,units:req.units,urgency:req.urgency,status:'pending',distanceKmApprox:Math.round(km*10)/10,stage,createdAt:now});already.add(snap.id);count++;
  }
  if(count){batch.update(db.collection('bloodRequests').doc(requestId),{notifiedDonorUids:[...already],escalationStage:stage,lastEscalatedAt:now,updatedAt:now});await batch.commit();}
  else if(stage>Number(req.escalationStage||0))await db.collection('bloodRequests').doc(requestId).update({escalationStage:stage,lastEscalatedAt:now,updatedAt:now});
  return count;
}
exports.matchNewBloodRequest = onDocumentCreated('bloodRequests/{requestId}', async event => {
  const req=event.data.data();if(req.status!=='Open')return;
  await createNotificationsForRadius(event.params.requestId,req,RADIUS_STAGES[0],0);
});
exports.respondToNotification = onCall(async request => {
  if(!request.auth)throw new HttpsError('unauthenticated','Please sign in first.');
  const {notificationId,response}=request.data||{};if(typeof notificationId!=='string'||!['accepted','declined'].includes(response))throw new HttpsError('invalid-argument','Invalid notification response.');
  const nRef=db.collection('notifications').doc(notificationId);
  return db.runTransaction(async tx=>{
    const nSnap=await tx.get(nRef);if(!nSnap.exists)throw new HttpsError('not-found','Notification not found.');const n=nSnap.data();
    if(n.donorUid!==request.auth.uid)throw new HttpsError('permission-denied','This notification belongs to another donor.');
    if(n.status!=='pending')throw new HttpsError('failed-precondition','This notification has already been answered.');
    const reqRef=db.collection('bloodRequests').doc(n.requestId);const reqSnap=await tx.get(reqRef);if(!reqSnap.exists||reqSnap.data().status!=='Open')throw new HttpsError('failed-precondition','This request is no longer open.');
    const responseRef=reqRef.collection('responses').doc(request.auth.uid);const old=await tx.get(responseRef);if(old.exists)throw new HttpsError('already-exists','You have already responded to this request.');
    tx.update(nRef,{status:response,respondedAt:FieldValue.serverTimestamp()});tx.set(responseRef,{donorUid:request.auth.uid,response,createdAt:FieldValue.serverTimestamp()});return {ok:true,response};
  });
});
exports.getAuthorizedDonorContact = onCall(async request => {
  if(!request.auth)throw new HttpsError('unauthenticated','Please sign in first.');
  const {requestId,donorUid}=request.data||{};if(typeof requestId!=='string'||typeof donorUid!=='string')throw new HttpsError('invalid-argument','Request and donor IDs are required.');
  const [rSnap,responseSnap,dSnap]=await Promise.all([db.collection('bloodRequests').doc(requestId).get(),db.collection('bloodRequests').doc(requestId).collection('responses').doc(donorUid).get(),db.collection('donors').doc(donorUid).get()]);
  if(!rSnap.exists||rSnap.data().ownerUid!==request.auth.uid)throw new HttpsError('permission-denied','Only the request owner may access an accepted donor contact.');
  if(!responseSnap.exists||responseSnap.data().response!=='accepted')throw new HttpsError('failed-precondition','The donor has not accepted this request.');
  if(!dSnap.exists||!dSnap.data().consent)throw new HttpsError('not-found','Donor contact is unavailable.');
  return {phone:dSnap.data().phone||null,fullName:dSnap.data().fullName||null};
});
// Reliable periodic expiration and radius escalation. Requires deployed Functions and Scheduler configuration.
exports.expireAndEscalateRequests = onSchedule('every 5 minutes', async () => {
  const now=admin.firestore.Timestamp.now();const open=await db.collection('bloodRequests').where('status','==','Open').limit(300).get();
  for(const snap of open.docs){const req=snap.data();if(req.requiredBy && req.requiredBy.toMillis && req.requiredBy.toMillis()<=now.toMillis()){await snap.ref.update({status:'Expired',updatedAt:now});continue;}
    const stage=Number(req.escalationStage||0);if(stage>=RADIUS_STAGES.length-1)continue;
    const last=req.lastEscalatedAt?.toMillis?req.lastEscalatedAt.toMillis():(req.createdAt?.toMillis?req.createdAt.toMillis():now.toMillis());
    if(now.toMillis()-last<ESCALATION_MINUTES*60*1000)continue;
    await createNotificationsForRadius(snap.id,req,RADIUS_STAGES[stage+1],stage+1);
  }
});
