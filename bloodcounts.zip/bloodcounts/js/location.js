export function getBrowserLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('Geolocation is not supported by this browser.'));
    navigator.geolocation.getCurrentPosition(
      position => resolve({ latitude: position.coords.latitude, longitude: position.coords.longitude }),
      error => reject(new Error(error.code === 1 ? 'Location permission was denied. Enter a city or choose a location manually.' : 'Could not determine your location. Please try again or enter a location manually.')),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 }
    );
  });
}
export function haversineKm(aLat, aLon, bLat, bLon) {
  const vals = [aLat, aLon, bLat, bLon].map(Number);
  if (vals.some(v => !Number.isFinite(v))) return Infinity;
  const [lat1, lon1, lat2, lon2] = vals;
  const rad = deg => deg * Math.PI / 180;
  const dLat = rad(lat2 - lat1), dLon = rad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function wireLocationButton(buttonId, statusId, latId, lonId) {
  const button = document.getElementById(buttonId); if (!button || !document.getElementById(latId) || !document.getElementById(lonId)) return;
  button.addEventListener('click', async () => {
    const status = document.getElementById(statusId); button.disabled = true;
    if (status) status.textContent = 'Requesting browser location permission…';
    try { const pos = await getBrowserLocation(); document.getElementById(latId).value = pos.latitude.toFixed(6); document.getElementById(lonId).value = pos.longitude.toFixed(6); if (status) status.textContent = 'Location added. You can edit these coordinates.'; }
    catch (err) { if (status) status.textContent = err.message; }
    finally { button.disabled = false; }
  });
}
wireLocationButton('useMyLocation', 'locationStatus', 'latitude', 'longitude');
wireLocationButton('requestLocationBtn', 'requestLocationStatus', 'requestLatitude', 'requestLongitude');
wireLocationButton('facilityLocationBtn', 'facilityLocationStatus', 'facilityLatitude', 'facilityLongitude');
