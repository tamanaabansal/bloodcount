// Configurable hackathon pre-screening only. A blood bank must make the final decision.
export const ELIGIBILITY_RULES = { minAge: 18, maxAge: 65, minWeightKg: 50, intervalMonths: { male: 3, female: 4, other: 4 } };
function monthsBetween(from, to) {
  let months = (to.getFullYear() - from.getFullYear()) * 12 + (to.getMonth() - from.getMonth());
  if (to.getDate() < from.getDate()) months -= 1;
  return months;
}
export function assessPreliminaryEligibility(donor, now = new Date(), rules = ELIGIBILITY_RULES) {
  const reasons = [];
  const age = Number(donor.age), weight = Number(donor.weightKg);
  if (!Number.isFinite(age) || age < rules.minAge || age > rules.maxAge) reasons.push(`Age must be ${rules.minAge}–${rules.maxAge} years`);
  if (!Number.isFinite(weight) || weight < rules.minWeightKg) reasons.push(`Weight must be at least ${rules.minWeightKg} kg`);
  if (donor.available !== true && donor.available !== 'yes') reasons.push('Donor is not currently available');
  if (donor.feelingHealthy !== true && donor.feelingHealthy !== 'yes') reasons.push('Donor has not reported feeling healthy');
  if (donor.lastDonationDate) {
    const last = new Date(`${donor.lastDonationDate}T00:00:00`);
    if (Number.isNaN(last.getTime())) reasons.push('Last donation date is invalid');
    else if (last > now) reasons.push('Last donation date cannot be in the future');
    else {
      const interval = rules.intervalMonths[donor.gender] ?? rules.intervalMonths.other;
      if (monthsBetween(last, now) < interval) reasons.push(`Donation interval has not reached ${interval} months`);
    }
  }
  return { eligible: reasons.length === 0, reasons, label: 'Preliminary eligibility — confirmation by blood bank required' };
}
