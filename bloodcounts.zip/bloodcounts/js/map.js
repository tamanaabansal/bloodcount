// Shared Leaflet helpers. Maps should only receive real configured records or explicitly labelled demo records.
export function createBaseMap(elementId, center = [30.3165, 78.0322], zoom = 6) {
  if (!window.L || !document.getElementById(elementId)) return null;
  const map = L.map(elementId).setView(center, zoom);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
  return map;
}
export function approximateMarker(map, latitude, longitude, label, kind = 'donor') {
  if (!map || !Number.isFinite(Number(latitude)) || !Number.isFinite(Number(longitude))) return null;
  const color = kind === 'facility' ? '#287c65' : kind === 'request' ? '#d18a19' : '#a71930';
  return L.circleMarker([Number(latitude), Number(longitude)], { radius: 7, color, fillColor: color, fillOpacity: .8 }).addTo(map).bindPopup(String(label || 'Location').replace(/[<>]/g, ''));
}
