const toggle = document.getElementById('menuToggle');
if (toggle) toggle.addEventListener('click', () => document.getElementById('mainNav')?.classList.toggle('open'));
export function setMessage(element, text, kind = '') { if (!element) return; element.textContent = text; element.className = `message ${kind}`.trim(); }
