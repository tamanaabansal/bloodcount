import { auth, db, firebaseReady, requireFirebase } from './firebase-config.js';
import { onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { addDoc, collection, doc, getDoc, serverTimestamp, updateDoc } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { setMessage } from './ui.js';
const form = document.getElementById('requestForm'); let user = null;
if (firebaseReady) onAuthStateChanged(auth, u => { user = u; });
form?.addEventListener('submit', async e => {
  e.preventDefault(); const msg = document.getElementById('requestMessage');
  try {
    requireFirebase(); if (!auth.currentUser) throw new Error('Please log in before submitting a blood request.');
    const f = new FormData(form), phone = String(f.get('contactPhone') || '').trim();
    if (!/^\+[1-9]\d{7,14}$/.test(phone)) throw new Error('Enter contact phone in international format, e.g. +919876543210.');
    const requiredBy = new Date(String(f.get('requiredBy'))); if (Number.isNaN(requiredBy.getTime())) throw new Error('Choose a valid required-by date and time.');
    if (requiredBy <= new Date()) throw new Error('Required-by time must be in the future.');
    const lat = f.get('latitude') ? Number(f.get('latitude')) : null, lon = f.get('longitude') ? Number(f.get('longitude')) : null;
    if ((lat === null) !== (lon === null) || (lat !== null && (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lon) || lon < -180 || lon > 180))) throw new Error('Enter valid latitude and longitude together.');
    const request = { ownerUid: auth.currentUser.uid, requesterName: String(f.get('requesterName')).trim(), bloodGroup: f.get('bloodGroup'), units: Number(f.get('units')), hospitalName: String(f.get('hospitalName')).trim(), hospitalAddress: String(f.get('hospitalAddress')).trim(), city: String(f.get('city')).trim(), locality: String(f.get('locality')).trim(), latitude: lat, longitude: lon, urgency: f.get('urgency'), requiredBy, contactName: String(f.get('contactName')).trim(), contactPhone: phone, notes: String(f.get('notes') || '').trim(), status: 'Open', escalationStage: 0, notifiedDonorUids: [], createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    if (!request.requesterName || !request.hospitalName || !request.hospitalAddress || !request.city || !request.locality || !request.contactName) throw new Error('Please complete all required fields.');
    const ref = await addDoc(collection(db, 'bloodRequests'), request);
    setMessage(msg, `Request created successfully. Reference: ${ref.id}. In-app matching notifications require the configured trusted backend.`, 'success'); form.reset();
  } catch (err) { setMessage(msg, err.message || 'Could not submit the request.', 'error'); }
});
