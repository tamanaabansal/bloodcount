import { auth, db, firebaseReady, requireFirebase } from './firebase-config.js';
import { onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { doc, getDoc, setDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { assessPreliminaryEligibility } from './eligibility.js';
import { setMessage } from './ui.js';
const form = document.getElementById('donorForm');
if (form) {
  const lastDate = form.elements.lastDonationDate;
  if (lastDate) lastDate.max = new Date().toISOString().slice(0, 10);
  let signedInUser = null;
  if (firebaseReady) onAuthStateChanged(auth, async user => {
    signedInUser = user;
    const msg = document.getElementById('donorMessage');
    if (!user) { setMessage(msg, 'Please create an account or log in before saving a donor profile.', 'error'); return; }
    try { const snap = await getDoc(doc(db, 'donors', user.uid)); if (snap.exists()) { const d = snap.data(); for (const [key, value] of Object.entries(d)) if (form.elements[key] && value != null) { if (form.elements[key].type === 'checkbox') form.elements[key].checked = Boolean(value); else form.elements[key].value = value; } } } catch (e) { setMessage(msg, 'Could not load your existing profile: ' + e.message, 'error'); }
  });
  form.addEventListener('submit', async e => {
    e.preventDefault(); const msg = document.getElementById('donorMessage');
    try {
      requireFirebase(); if (!signedInUser) throw new Error('Please log in first.');
      const f = new FormData(form); const phone = String(f.get('phone') || '').trim();
      if (!/^\+[1-9]\d{7,14}$/.test(phone)) throw new Error('Enter phone number in international format, e.g. +919876543210.');
      const email = String(f.get('email') || '').trim(); if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.');
      const age = Number(f.get('age')), weightKg = Number(f.get('weightKg'));
      if (!Number.isInteger(age) || age < 18 || age > 65) throw new Error('For this preliminary screening, age must be 18–65 years.');
      if (!Number.isFinite(weightKg) || weightKg < 50) throw new Error('For this preliminary screening, weight must be at least 50 kg.');
      const lastDonationDate = String(f.get('lastDonationDate') || ''); if (lastDonationDate && lastDonationDate > new Date().toISOString().slice(0, 10)) throw new Error('Last donation date cannot be in the future.');
      const lat = f.get('latitude') ? Number(f.get('latitude')) : null, lon = f.get('longitude') ? Number(f.get('longitude')) : null;
      if ((lat === null) !== (lon === null) || (lat !== null && (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lon) || lon < -180 || lon > 180))) throw new Error('Enter valid latitude and longitude together.');
      const donor = { uid: signedInUser.uid, fullName: String(f.get('fullName')).trim(), phone, email: email || null, bloodGroup: f.get('bloodGroup'), age, weightKg, gender: f.get('gender'), state: String(f.get('state')).trim(), city: String(f.get('city')).trim(), locality: String(f.get('locality')).trim(), lastDonationDate: lastDonationDate || null, available: f.get('available') === 'yes', feelingHealthy: f.get('feelingHealthy') === 'yes', latitude: lat, longitude: lon, consent: f.get('consent') === 'on', active: true };
      if (!donor.fullName || !donor.city || !donor.locality || !donor.consent) throw new Error('Complete all required fields and contact consent.');
      const assessment = assessPreliminaryEligibility(donor); donor.preliminaryEligible = assessment.eligible; donor.eligibilityReasons = assessment.reasons; donor.updatedAt = serverTimestamp();
      const old = await getDoc(doc(db, 'donors', signedInUser.uid)); if (!old.exists()) donor.createdAt = serverTimestamp();
      await setDoc(doc(db, 'donors', signedInUser.uid), donor, { merge: true });
      setMessage(msg, assessment.eligible ? 'Donor profile saved. Preliminary checks passed; a blood bank must confirm final eligibility.' : `Profile saved, but preliminary checks flagged: ${assessment.reasons.join('; ')}.`, assessment.eligible ? 'success' : 'error');
    } catch (err) { setMessage(msg, err.message || 'Could not save profile.', 'error'); }
  });
}
