// Browser-facing helpers. The backend, not the browser, must authorize acceptance/contact disclosure.
import { functions, firebaseReady } from './firebase-config.js';
import { httpsCallable } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js';
export async function respondToNotification(notificationId, response) {
  if (!firebaseReady || !functions) throw new Error('Firebase Functions is not configured.');
  if (!['accepted', 'declined'].includes(response)) throw new Error('Response must be accepted or declined.');
  const call = httpsCallable(functions, 'respondToNotification');
  return call({ notificationId, response });
}
export async function getAuthorizedContact(requestId, donorUid) {
  if (!firebaseReady || !functions) throw new Error('Firebase Functions is not configured.');
  const call = httpsCallable(functions, 'getAuthorizedDonorContact');
  return call({ requestId, donorUid });
}
