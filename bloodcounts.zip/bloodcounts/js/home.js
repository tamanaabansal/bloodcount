const menuToggle = document.getElementById('menuToggle');
menuToggle?.addEventListener('click', () => document.getElementById('mainNav')?.classList.toggle('open'));
import { firebaseReady, db } from './firebase-config.js';
import { collection, getDocs, limit, query, where } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
const quick = document.getElementById('quickSearch');
quick?.addEventListener('submit', e => { e.preventDefault(); const group = document.getElementById('quickBloodGroup').value; const city = document.getElementById('quickCity').value.trim(); const params = new URLSearchParams({ group, city }); location.href = `find-donors.html?${params}`; });
if (window.L && document.getElementById('homeMap')) {
  const map = L.map('homeMap').setView([30.3165, 78.0322], 6);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
  if (firebaseReady) getDocs(query(collection(db, 'facilities'), where('active', '==', true), limit(100))).then(snap => snap.forEach(doc => { const f = doc.data(); if (Number.isFinite(f.latitude) && Number.isFinite(f.longitude)) L.marker([f.latitude, f.longitude]).addTo(map).bindPopup(`${String(f.name || 'Facility').replace(/[<>]/g, '')}<br>${String(f.type || 'Facility').replace(/[<>]/g, '')}`); })).catch(() => {});
}
