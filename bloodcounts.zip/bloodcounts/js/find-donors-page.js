import { db, firebaseReady } from './firebase-config.js';
import { isBloodGroupCompatible } from './compatibility.js';
import { assessPreliminaryEligibility } from './eligibility.js';
import { haversineKm, getBrowserLocation } from './location.js';
import { collection, getDocs, limit, query, where } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
const form = document.getElementById('findForm'), results = document.getElementById('donorResults'), message = document.getElementById('searchMessage');
let map, markers, currentLocation = null;
if (window.L && document.getElementById('donorMap')) { map = L.map('donorMap').setView([30.3165, 78.0322], 6); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map); markers = L.layerGroup().addTo(map); }
const escapeHtml = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const params = new URLSearchParams(location.search); if (params.get('group')) document.getElementById('recipientGroup').value = params.get('group'); if (params.get('city')) document.getElementById('searchCity').value = params.get('city');
async function searchDonors() {
  const group = document.getElementById('recipientGroup').value, city = document.getElementById('searchCity').value.trim().toLowerCase(), maxKm = Number(document.getElementById('maxDistance').value || 50);
  if (!group) { message.textContent = 'Select a recipient blood group first.'; message.className = 'message error'; return; }
  results.replaceChildren(Object.assign(document.createElement('p'), { textContent: 'Searching donor profiles…' })); document.getElementById('resultCount').textContent = 'Searching…'; message.textContent = '';
  if (!firebaseReady) { results.replaceChildren(); const empty = document.createElement('div'); empty.className = 'empty-state'; empty.innerHTML = '<h3>Firebase setup required</h3><p>Add your Firebase configuration and publish Firestore rules to search real donor records.</p>'; results.append(empty); document.getElementById('resultCount').textContent = 'Not connected'; return; }
  try {
    // The collection is private by default in the recommended rules. For public discovery, use a sanitized donorSearch collection populated by a trusted backend.
    const snap = await getDocs(query(collection(db, 'donorSearch'), where('active', '==', true), where('available', '==', true), limit(500)));
    let donors = snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(d => isBloodGroupCompatible(d.bloodGroup, group));
    donors = donors.filter(d => assessPreliminaryEligibility(d).eligible);
    if (city) donors = donors.filter(d => `${d.city || ''} ${d.locality || ''} ${d.state || ''}`.toLowerCase().includes(city));
    donors = donors.map(d => ({ ...d, distance: currentLocation && Number.isFinite(d.latitude) && Number.isFinite(d.longitude) ? haversineKm(currentLocation.latitude, currentLocation.longitude, d.latitude, d.longitude) : null })).filter(d => d.distance == null || d.distance <= maxKm).sort((a,b) => (a.distance ?? Infinity) - (b.distance ?? Infinity));
    results.replaceChildren(); markers?.clearLayers();
    if (!donors.length) { const empty = document.createElement('div'); empty.className = 'empty-state'; empty.innerHTML = '<span>♥</span><h3>No matching profiles found</h3><p>Try a wider distance or another locality. Contact a hospital blood bank for urgent needs.</p>'; results.append(empty); }
    for (const d of donors) {
      const card = document.createElement('article'); card.className = 'donor-result';
      const h = document.createElement('h3'); h.textContent = d.fullName || 'Registered donor'; card.append(h);
      const p = document.createElement('p'); p.textContent = `${d.bloodGroup} · ${d.locality || 'Locality not provided'}, ${d.city || 'City not provided'}`; card.append(p);
      const status = document.createElement('span'); status.className = 'pill'; status.textContent = 'Available · Preliminary checks passed'; card.append(status);
      const dist = document.createElement('p'); dist.textContent = d.distance == null ? 'Distance unavailable — set your location to sort by distance.' : `Approximately ${d.distance.toFixed(1)} km away`; card.append(dist);
      const privacy = document.createElement('p'); privacy.textContent = 'Contact details are private. Use the authorized request-response flow.'; card.append(privacy); results.append(card);
      if (map && Number.isFinite(d.latitude) && Number.isFinite(d.longitude)) L.circleMarker([d.latitude, d.longitude], { radius: 7, color: '#a71930' }).addTo(markers).bindPopup(`${escapeHtml(d.bloodGroup)} · ${escapeHtml(d.city || 'City not provided')}<br>Approximate location`);
    }
    document.getElementById('resultCount').textContent = `${donors.length} potential match${donors.length === 1 ? '' : 'es'}`;
    if (donors.length && map) { const pts = donors.filter(d => Number.isFinite(d.latitude) && Number.isFinite(d.longitude)).map(d => [d.latitude, d.longitude]); if (pts.length) map.fitBounds(pts, { padding: [25,25], maxZoom: 12 }); }
  } catch (err) { results.replaceChildren(); const p = document.createElement('p'); p.textContent = `Could not search donor profiles: ${err.message}. Ensure the sanitized donorSearch collection is populated by trusted backend code and rules permit safe reads.`; results.append(p); document.getElementById('resultCount').textContent = 'Search failed'; }
}
form?.addEventListener('submit', e => { e.preventDefault(); searchDonors(); }); document.getElementById('refreshDonors')?.addEventListener('click', searchDonors);
// Optional location button for donor discovery.
const locationButton = document.createElement('button'); locationButton.type='button'; locationButton.className='btn btn-outline'; locationButton.textContent='Use my location for distance'; locationButton.addEventListener('click', async () => { try { currentLocation = await getBrowserLocation(); message.textContent='Location set for approximate distance sorting.'; message.className='message success'; searchDonors(); } catch(e) { message.textContent=e.message; message.className='message error'; } }); form?.append(locationButton);
if (params.get('group')) searchDonors();
