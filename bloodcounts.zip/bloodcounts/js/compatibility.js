// Recipient-to-donor red blood cell compatibility. This is a preliminary search filter only.
export const BLOOD_GROUPS = ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'];
const compatibleDonors = {
  'O-': ['O-'], 'O+': ['O-', 'O+'], 'A-': ['O-', 'A-'],
  'A+': ['O-', 'O+', 'A-', 'A+'], 'B-': ['O-', 'B-'],
  'B+': ['O-', 'O+', 'B-', 'B+'], 'AB-': ['O-', 'A-', 'B-', 'AB-'],
  'AB+': BLOOD_GROUPS
};
export function isBloodGroupCompatible(donorGroup, recipientGroup) {
  return Boolean(compatibleDonors[recipientGroup]?.includes(donorGroup));
}
export function getCompatibleDonorGroups(recipientGroup) {
  return [...(compatibleDonors[recipientGroup] || [])];
}
